import React from 'react';


function Login(){
  
return(
    
  <div classname='Login'>
   <body>
   
   <form>
     <div class="box1">
        <h2 class="lgn">Login</h2>
        <label class="uid">UserID </label>
        <input type="text" placeholder="Enter your UserID"/>
        <br></br>
        <br></br>
        <label class="up">Password </label>
        <input type="text" placeholder="Enter your Password"/>
        <br></br>
        <br></br>
        <div class="btn1">
        <input class="btn" type="button"  value="login" onclick="changeType"/>
        </div>
        </div>
   </form>
   </body>
   </div> 
   
       
);   
}

export default Login;